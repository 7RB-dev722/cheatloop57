import React, { useState, useEffect } from 'react';
import { GamingProductCard } from './GamingProductCard';
import { productService, categoryService, Product, Category } from '../lib/supabase';

export const ProductsGrid: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const [allProducts, allCategories] = await Promise.all([
        productService.getVisibleProducts(), // Fetch only visible products
        categoryService.getAllCategories()
      ]);
      
      setProducts(allProducts);
      setCategories(allCategories);
    } catch (err: any) {
      console.error('Error loading data:', err);
      
      if (err.message.includes('is_hidden')) {
        setError('Database is updating. Loading backup data.');
        
        try {
          const fallbackProducts = await productService.getAllProducts();
          const fallbackCategories = await categoryService.getAllCategories();
          setProducts(fallbackProducts.filter(p => !p.is_hidden));
          setCategories(fallbackCategories);
          setError(null);
        } catch (fallbackErr) {
          console.error('Fallback also failed:', fallbackErr);
          loadFallbackData();
        }
      } else {
        setError('Failed to load products from the database.');
        loadFallbackData();
      }
    } finally {
      setLoading(false);
    }
  };

  const loadFallbackData = () => {
    const fallbackCategories: Category[] = [
      { id: 'pubg-fallback', name: 'PUBG Mobile', slug: 'pubg' },
      { id: 'codm-fallback', name: 'Call of Duty Mobile', slug: 'codm' }
    ];

    const fallbackProducts: Product[] = [
      {
        id: 'fallback-1',
        title: 'Cheatloop ESP',
        price: 40,
        features: ['Enemy Location Only (ESP)', 'Lightweight & Fast', 'No Aim Assist', 'Tactical Advantage'],
        description: 'A lightweight, safe tool that provides precise enemy location (ESP) without any aim assist or combat enhancements. Perfect for players who want a tactical edge without risking bans.',
        buy_link: 'https://checkout.thewayl.com/pay?id=cmcdygy8u005x9408h9rd85bm',
        video_link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        image: '/cheatloop.png',
        is_popular: false,
        is_hidden: false,
        category: 'pubg',
        category_id: 'pubg-fallback'
      },
      {
        id: 'fallback-2',
        title: 'Cheatloop Normal',
        price: 45,
        features: ['ESP + Aimbot', 'Smooth Combat System', 'Enhanced Performance', 'Account Protection'],
        description: 'Combines accurate enemy detection with a smooth aimbot system. Designed for players who want better combat performance while keeping their main account secure.',
        buy_link: 'https://checkout.thewayl.com/pay?id=cmcdyeeft005w9408abqrir22',
        video_link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        image: '/cheatloop.png',
        is_popular: true,
        is_hidden: false,
        category: 'pubg',
        category_id: 'pubg-fallback'
      },
      {
        id: 'fallback-3',
        title: 'Cheatloop Exclusive',
        price: 50,
        features: ['ESP + Aimbot + Magic Bullet', 'Wall Penetration', 'Pro Player Features', 'Maximum Control'],
        description: 'The most powerful Cheatloop version. Includes magic bullet for shooting through walls, combined with aimbot and ESP. Built for pro players looking for full control with top-level protection.',
        buy_link: 'https://checkout.thewayl.com/pay?id=cmcdyhxe9005y9408p4lsj477',
        video_link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        image: '/cheatloop.png',
        is_popular: false,
        is_hidden: false,
        category: 'pubg',
        category_id: 'pubg-fallback'
      },
      {
        id: 'fallback-4',
        title: 'Sinki Silver',
        price: 40,
        features: ['ESP Only', 'Simple & Stable', 'Wallhack Solution', 'Information Advantage'],
        description: 'Simple and stable wallhack solution that shows enemy positions only. Ideal for cautious players who want information without taking risks.',
        buy_link: 'https://checkout.thewayl.com/pay?id=cmcdygy8u005x9408h9rd85bm',
        video_link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        image: '/sinki.jpg',
        is_popular: false,
        is_hidden: false,
        category: 'pubg',
        category_id: 'pubg-fallback'
      },
      {
        id: 'fallback-5',
        title: 'Sinki Gold',
        price: 45,
        features: ['ESP + Aimbot + Magic Bullet', 'Premium Features', 'Devastating Accuracy', 'Combat Domination'],
        description: 'A premium version combining ESP, powerful aimbot, and magic bullet for devastating accuracy. Great for dominating fights while staying protected from bans.',
        buy_link: 'https://checkout.thewayl.com/pay?id=cmcdyeeft005w9408abqrir22',
        video_link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        image: '/sinki.jpg',
        is_popular: false,
        is_hidden: false,
        category: 'pubg',
        category_id: 'pubg-fallback'
      },
      {
        id: 'fallback-6',
        title: 'Sinki TDM (Streamer Edition)',
        price: 50,
        features: ['Overpowered TDM Abilities', 'Streamer Optimized', 'Warehouse/TDM Mode', 'Legend Performance'],
        description: 'Specially made for streamers and pro TDM players, this version provides superior combat power specifically for Warehouse/TDM mode in PUBG Mobile. Compete like a legend without fear of bans.',
        buy_link: 'https://checkout.thewayl.com/pay?id=cmcdyhxe9005y9408p4lsj477',
        video_link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        image: '/sinki.jpg',
        is_popular: false,
        is_hidden: false,
        category: 'pubg',
        category_id: 'pubg-fallback'
      }
    ];
    
    setProducts(fallbackProducts);
    setCategories(fallbackCategories);
  };

  const getProductsByCategory = (categoryId: string) => {
    return products.filter(product => product.category_id === categoryId);
  };

  if (loading) {
    return (
      <section className="py-20 relative overflow-hidden">
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400 mx-auto mb-4"></div>
            <p className="text-white">Loading Products...</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0">
        {/* Animated Grid Background */}
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: 'linear-gradient(to right, #06b6d4 1px, transparent 1px), linear-gradient(to bottom, #06b6d4 1px, transparent 1px)',
            backgroundSize: '60px 60px',
            animation: 'gridMove 25s linear infinite'
          }}
        ></div>
        
        {/* Floating Particles */}
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className={`absolute rounded-full blur-xl opacity-30 animate-float ${
              i % 3 === 0 ? 'bg-blue-500' : i % 3 === 1 ? 'bg-purple-500' : 'bg-pink-500'
            }`}
            style={{
              width: `${Math.random() * 200 + 100}px`,
              height: `${Math.random() * 200 + 100}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 2}s`,
              animationDuration: `${15 + Math.random() * 10}s`
            }}
          ></div>
        ))}

        {/* Gradient Overlays */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-transparent"></div>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        {/* Error Message */}
        {error && (
          <div className="text-center mb-8">
            <div className="bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 p-4 rounded-xl mb-6 max-w-2xl mx-auto">
              <p>{error}</p>
              <button 
                onClick={loadData}
                className="mt-4 text-yellow-300 hover:text-yellow-200 underline"
              >
                Retry
              </button>
            </div>
          </div>
        )}

        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent animate-fade-in-up">
            Gaming Arsenal
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
            Professional tools designed for competitive players. Choose your weapon and dominate the battlefield.
          </p>
          
          {/* Decorative Elements */}
          <div className="flex justify-center items-center space-x-4 mt-8 animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
            <div className="w-16 h-0.5 bg-gradient-to-r from-transparent to-cyan-400"></div>
            <div className="w-3 h-3 bg-cyan-400 rounded-full animate-pulse"></div>
            <div className="w-16 h-0.5 bg-gradient-to-r from-cyan-400 to-purple-400"></div>
            <div className="w-3 h-3 bg-purple-400 rounded-full animate-pulse" style={{ animationDelay: '0.5s' }}></div>
            <div className="w-16 h-0.5 bg-gradient-to-r from-purple-400 to-transparent"></div>
          </div>
        </div>

        {/* Products by Category */}
        {categories.map((category, categoryIndex) => {
          const categoryProducts = getProductsByCategory(category.id);
          
          if (categoryProducts.length === 0) return null;

          return (
            <div 
              key={category.id} 
              className="mb-20"
              style={{
                animation: `fadeInUp 0.8s ease-out ${categoryIndex * 0.3}s both`
              }}
            >
              {/* Category Header */}
              <div className="text-center mb-12">
                <div className="relative inline-block">
                  <h3 className="text-4xl md:text-5xl font-bold text-white mb-4 relative z-10">
                    {category.name}
                  </h3>
                  <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 blur-2xl rounded-full transform scale-150"></div>
                </div>
                <div className="w-24 h-1 bg-gradient-to-r from-cyan-400 to-purple-400 mx-auto rounded-full"></div>
              </div>

              {/* Category Products Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {categoryProducts.map((product, productIndex) => (
                  <div 
                    key={product.id} 
                    className="flex justify-center"
                    style={{
                      animation: `fadeInUp 0.8s ease-out ${(categoryIndex * 0.3) + (productIndex * 0.1)}s both`
                    }}
                  >
                    <GamingProductCard 
                      title={product.title}
                      price={product.price}
                      features={product.features}
                      description={product.description}
                      safety="Safe for Main Accounts"
                      buyLink={product.buy_link}
                      videoLink={product.video_link}
                      tier={product.price <= 40 ? 'basic' : product.price <= 45 ? 'premium' : 'exclusive'}
                      isPopular={product.is_popular}
                      image={product.image}
                      brand={product.title.toLowerCase().includes('cheatloop') ? 'cheatloop' : 'sinki'}
                    />
                  </div>
                ))}
              </div>

              {/* Category Separator */}
              {categoryIndex < categories.length - 1 && (
                <div className="mt-16 flex justify-center">
                  <div className="flex items-center space-x-4">
                    <div className="w-32 h-0.5 bg-gradient-to-r from-transparent to-gray-600"></div>
                    <div className="w-3 h-3 bg-gray-600 rounded-full animate-pulse"></div>
                    <div className="w-32 h-0.5 bg-gradient-to-r from-gray-600 to-transparent"></div>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {/* Bottom CTA Section */}
        <div className="text-center animate-fade-in-up" style={{ animationDelay: '1.2s' }}>
          <div className="bg-gradient-to-r from-slate-800/50 to-slate-900/50 backdrop-blur-xl rounded-2xl p-8 border border-slate-700/50">
            <h3 className="text-2xl font-bold text-white mb-4">
              Ready to Level Up Your Game?
            </h3>
            <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
              Join thousands of players who trust our tools for competitive gaming. 
              Safe, reliable, and constantly updated.
            </p>
            <div className="flex justify-center items-center space-x-6">
              <a
                href="https://discord.gg/sY5EcUVjeA"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl transition-all duration-300 transform hover:scale-105 font-medium shadow-lg hover:shadow-indigo-500/25"
              >
                <span>Join Discord</span>
              </a>
              <a
                href="https://api.whatsapp.com/send?phone=9647832941204"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-xl transition-all duration-300 transform hover:scale-105 font-medium shadow-lg hover:shadow-green-500/25"
              >
                <span>Contact Support</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
